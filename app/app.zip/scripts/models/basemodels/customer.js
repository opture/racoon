﻿var Customer = function (options) {
    var self = this;
    options = options || {};
    options.customerContacts = options.customerContacts || [];
    self.id = options.id || 0;
    self.name = options.name || '';
    self.address = options.address || '';
    self.address2 = options.address2 || '';
    self.city = options.city || '';
    self.zip = options.zip || '';
    self.vatNumber = options.vatNumber || '';
    self.contacts = [];

    self.initContacts = function () {
        if (options.customerContacts) {
            options.customerContacts.forEach(function (contact, index) {
                self.contacts.push(new CustomerContact(contact));
            });
        }
        if (options.contacts) {
            options.contacts.forEach(function (contact, index) {
                self.contacts.push(new CustomerContact(contact));
            });
        }
    }();
}
