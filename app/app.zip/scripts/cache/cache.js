﻿var Cache = function () {
    //var self = riot.observable(this);
    var self = this;
    //Add item or collection to cache.
    self.addCacheItem = function (key, data) {
        self.cachedItems[key] = data;
        //self.trigger('cacheItemAdded', key, data);
    };

    //Get item or collection from cache
    self.getCacheItem = function (key) {
        return self.cachedItems[key];
    };

    //Execute when cacheitems are added-
    self.on('cacheItemAdded', function (key, data) {
        console.log('Item ' + key + ' added to cache');
    });
    self.cachedItems = {};
}